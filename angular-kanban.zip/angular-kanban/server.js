var express = require('express');
var app = express();

var path = require("path");

var __dirname = path.resolve();

app.use('/public', express.static(__dirname + '/public'));
app.use('/node_modules', express.static(__dirname + 'node_modules'));
app.listen('4000', function() {
    console.log('server started');
});
app.get('/', function(request, response){
    response.sendFile('landing.html',{'root':__dirname + '/public'});
});