var app = angular.module('mainApp', [
    'ngRoute',
    'kanban'
]);
app.config(['$routeProvider',function($routeProvider){
    $routeProvider.otherwise({
        redirectTo : '/kanban'
    });
}])