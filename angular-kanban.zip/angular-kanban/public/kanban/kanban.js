
angular.module('kanban', ['ngRoute'])
.config(['$routeProvider',function($routeProvider){
    $routeProvider.when('/kanban', {
      controller: 'KanbanCtrl',
      templateUrl: 'public/kanban/kanban.html',
      css:'public/customcss/landing.css'
    });
}])
.controller('KanbanCtrl', function($scope,$http){
  $scope.myData = {};
    $http({
        method : "GET",
        url : "public/data.json"
    }).then(function mySuccess(response) {
      $scope.myData = response.data.records;
    }, function myError(response) {
      $scope.myData = response.statusText;
    });
});